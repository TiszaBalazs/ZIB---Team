let isOn = false;
let temperature = 20; // Kezdeti hőmérséklet
let logData = [];
let energyLogData = [];
let intervalId = null;
let energyIntervalId = null;
let powerConsumption = 2; // kW, a vízforraló átlagos teljesítménye
let timeElapsed = 0; // Eltelt idő a logoláshoz (percben)

// Hőmérséklet beállítása bemenet alapján
document.getElementById('inputTemperature').addEventListener('input', function() {
    temperature = parseInt(this.value);
    updateTemperatureDisplay();
});

// Bekapcsolás és hőmérséklet változtatás logikája
function toggleBoiler() {
    const button = document.getElementById('toggleButton');
    if (!isOn) {
        isOn = true;
        button.textContent = 'Kikapcsolás';
        button.classList.remove('off');
        startHeating();
        startLogging(); // Logolás indítása
    } else {
        isOn = false;
        button.textContent = 'Bekapcsolás';
        button.classList.add('off');
        clearInterval(intervalId);
        clearInterval(energyIntervalId); // Hőmérséklet növekedés és logolás leállítása
        startCooling();
    }
}

// Fűtés indítása
function startHeating() {
    intervalId = setInterval(() => {
        if (temperature < 100) {
            temperature++;
            updateTemperatureDisplay();
        } else {
            clearInterval(intervalId);
            toggleBoiler(); // Automatikus kikapcsolás 100 fok elérése után
        }
    }, 4000); // 4 másodpercenként emelkedik 1 fokkal
}

// Hűtés indítása
function startCooling() {
    intervalId = setInterval(() => {
        if (temperature > 18) {
            if (temperature > 80) {
                temperature -= 10;
            } else if (temperature > 50) {
                temperature -= 5;
            } else {
                temperature -= 2;
            }
            updateTemperatureDisplay();
        } else {
            clearInterval(intervalId); // Ha elérjük a 18 fokot, leállítjuk a hűlést
        }
    }, 60000); // 1 percenként csökken a hőmérséklet
}

// Hőmérséklet frissítése a képernyőn
function updateTemperatureDisplay() {
    document.getElementById('temperature').textContent = temperature;
}

// Áramfogyasztás számítása
function calculateEnergyConsumption() {
    return powerConsumption / 60; // kWh percre lebontva
}

// Adatok logolása percenként
function startLogging() {
    timeElapsed = 0;
    energyIntervalId = setInterval(() => {
        // Csak addig logolunk, amíg az idő el nem éri a 90 percet
        if (timeElapsed <= 90) {
            logData.push(temperature);
            if (isOn) {
                energyLogData.push(calculateEnergyConsumption());
            } else {
                energyLogData.push(0); // Kikapcsolt állapotban nincs áramfogyasztás
            }
            timeElapsed++;
            displayLogs();
        } else {
            clearInterval(energyIntervalId); // Maximum 90 perc logolás
        }
    }, 60000); // 1 percenként logolunk
}

// Adatok megjelenítése
function displayLogs() {
    const logElement = document.getElementById('log');
    const energyLogElement = document.getElementById('energyLog');
    let logText = '';
    let energyLogText = '';
    
    for (let i = 0; i < logData.length; i++) {
        logText += logData[i] + ' °C\t';
        energyLogText += energyLogData[i].toFixed(3) + ' kWh\t';
        
        // Minden 10. adat után új sort kezdünk
        if ((i + 1) % 10 === 0) {
            logText += '\n';
            energyLogText += '\n';
        }
    }
    logElement.textContent = logText;
    energyLogElement.textContent = energyLogText;
}

// Bekapcsolás esemény kezelése
document.getElementById('toggleButton').addEventListener('click', toggleBoiler);
